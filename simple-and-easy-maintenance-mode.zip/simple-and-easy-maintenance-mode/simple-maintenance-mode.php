<?php
/*
Plugin Name: Simple And Easy Maintenance Mode
Description: Displays a maintenance message on the site. This is a simple and easy maintenance mode plugin. Just set the message text, color, size and you are all set.
Version: 1.0
Author: Basit Amjad
*/

// Add plugin settings menu
function maintenance_mode_menu() {
    add_options_page(
        'Maintenance Mode',
        'Maintenance Mode',
        'manage_options',
        'maintenance-mode',
        'maintenance_mode_settings'
    );
}
add_action('admin_menu', 'maintenance_mode_menu');

// Render plugin settings page
function maintenance_mode_settings() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }

    // Save settings
    if (isset($_POST['submit'])) {
        $maintenance_mode = isset($_POST['maintenance_mode']) ? 1 : 0;
        $message = sanitize_text_field($_POST['message']);
        $image_url = esc_url_raw($_POST['image_url']);
        $message_color = sanitize_hex_color($_POST['message_color']);
        $message_size = absint($_POST['message_size']);

        update_option('maintenance_mode', $maintenance_mode);
        update_option('maintenance_message', $message);
        update_option('maintenance_image_url', $image_url);
        update_option('maintenance_message_color', $message_color);
        update_option('maintenance_message_size', $message_size);
		
		// Save the allowed IP address
        $allowed_ip = sanitize_text_field($_POST['allowed_ip']);
        update_option('maintenance_allowed_ip', $allowed_ip);


        echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
    }

	 // Get the current IP address
    $current_ip = $_SERVER['REMOTE_ADDR'];

    // Display settings form
    $maintenance_mode = get_option('maintenance_mode', 0);
    $message = get_option('maintenance_message', 'The site is currently under maintenance.');
    $image_url = get_option('maintenance_image_url', '');
    $message_color = get_option('maintenance_message_color', '#000000');
    $message_size = get_option('maintenance_message_size', 16);
    ?>
    <div class="wrap">
        <h1>Maintenance Mode Settings</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr>
                    <th scope="row">Enable Maintenance Mode</th>
                    <td><input type="checkbox" name="maintenance_mode" <?php checked($maintenance_mode, 1); ?> /></td>
                </tr>
                <tr>
                    <th scope="row">Message</th>
                    <td><textarea name="message" rows="5" cols="50"><?php echo $message; ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row">Image URL</th>
                    <td><input type="text" name="image_url" value="<?php echo $image_url; ?>" size="50" /></td>
                </tr>
                <tr>
                    <th scope="row">Message Color</th>
                    <td><input type="color" name="message_color" value="<?php echo $message_color; ?>" /></td>
                </tr>
                <tr>
                    <th scope="row">Message Size</th>
                    <td><input type="number" name="message_size" value="<?php echo $message_size; ?>" min="1" max="100" /></td>
                </tr>
				<!-- New IP restriction field -->
                <tr>
                    <th scope="row">Do not restrict my IP</th>
                    <td>
                        <input type="text" name="allowed_ip" value="<?php echo esc_attr(get_option('maintenance_allowed_ip', '')); ?>" size="50" />
                        <button type="button" id="find-my-ip">Find my IP</button>
                    </td>
                </tr>
            </table>
            <!-- ... -->
            </table>
            <p class="submit"><input type="submit" name="submit" class="button-primary" value="Save Settings" /></p>
        </form>
    </div>
	 <script>
        (function($) {
            // Function to find user's IP address
            function findMyIP() {
			// Display the waiting message
            $('input[name="allowed_ip"]').val('Trying to detect your IP, please wait...');

                $.getJSON('https://api.ipify.org?format=json')
                    .done(function(data) {
                        $('input[name="allowed_ip"]').val(data.ip);
                    })
                    .fail(function(jqXHR, textStatus, errorThrown) {
                        console.error('Error:', textStatus, errorThrown);
                    });
            }

            // Bind click event to the "Find my IP" button
            $('#find-my-ip').on('click', function() {
                findMyIP();
            });

            // Populate IP field with user's IP on page load
            $(document).ready(function() {
                findMyIP();
            });
        })(jQuery);
    </script>
    <?php
}

// Check if maintenance mode is enabled
function maintenance_mode_check() {
    $maintenance_mode = get_option('maintenance_mode', 0);
    $allowed_ip = get_option('maintenance_allowed_ip', '');
	$user_ip = get_user_ip_address();
	
    if ($maintenance_mode && !current_user_can('manage_options') && $allowed_ip !== $user_ip) {
        $message = get_option('maintenance_message', 'The site is currently under maintenance.');
        $image_url = get_option('maintenance_image_url', '');
        $message_color = get_option('maintenance_message_color', '#000000');
        $message_size = get_option('maintenance_message_size', 16);

        echo '<div style="text-align: center; margin: 50px auto;">';
        if (!empty($image_url)) {
            echo '<img src="' . esc_url($image_url) . '" alt="Maintenance Image" style="max-width: 100%;" /><br /><br />';
        }
        echo '<p style="color: ' . $message_color . '; font-size: ' . $message_size . 'px;">' . $message . '</p>';
        echo '</div>';

        exit;
    }
}

function get_user_ip_address() {
    $ip = '';

    // Make a request to ipapi API
    $response = wp_remote_get('https://ipapi.co/json/');

    // Check if the request was successful
    if (is_array($response) && !empty($response['body'])) {
        $body = json_decode($response['body']);

        // Retrieve the IP address from the response
        if (isset($body->ip)) {
            $ip = $body->ip;
        }
    }

    return $ip;
}





add_action('template_redirect', 'maintenance_mode_check');
