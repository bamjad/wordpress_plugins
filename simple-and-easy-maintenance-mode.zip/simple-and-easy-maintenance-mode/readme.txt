=== Simple And Easy Maintenance Mode ===
Contributors: basitamjad
Donate link: https://github.com/sponsors/bamjad
Tags: maintenance mode
Requires at least: 4.7
Tested up to: 5.4
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Simple Maintenance Mode allows site administrator to put site in maintenance mode.

== Description ==

As the name suggests, this is a simple way to set your site in maintenance mode. You can set the message, color and message size

== Frequently Asked Questions ==

= What is my ip address is not detected by the plugin =

You can input your ip address manually.

== Screenshots ==

1. This screen shot description corresponds to screenshot.png.

== Changelog ==

= 1.0 =
* This is the first version of the plugin.

== Upgrade Notice ==

= 1.1 =
Newer version will have new features so if you want to use new features, consider upgrades when available


== A brief Markdown Example ==

Markdown is what the parser uses to process much of the readme file.

[markdown syntax]: https://daringfireball.net/projects/markdown/syntax

Ordered list:

1. Message color
2. Message size
3. Can bypass your ip address if you have entered or used "Find my ip" button

Unordered list:

* Message color
* Message size
* Can bypass your ip address if you have entered or used "Find my ip" button

Links require brackets and parenthesis:

Here's a link to [WordPress](https://wordpress.org/ "Your favorite software") and one to [Markdown's Syntax Documentation][markdown syntax]. Link titles are optional, naturally.

Blockquotes are email style:

> Asterisks for *emphasis*. Double it up  for **strong**.

And Backticks for code:

`<?php code(); ?>`